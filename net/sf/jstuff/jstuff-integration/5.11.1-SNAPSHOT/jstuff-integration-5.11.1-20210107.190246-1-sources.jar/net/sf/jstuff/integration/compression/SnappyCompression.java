/*
 * Copyright 2010-2021 by Sebastian Thomschke and contributors.
 * SPDX-License-Identifier: EPL-2.0
 */
package net.sf.jstuff.integration.compression;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.xerial.snappy.SnappyInputStream;
import org.xerial.snappy.SnappyOutputStream;

import net.sf.jstuff.core.Strings;
import net.sf.jstuff.core.collection.ArrayUtils;
import net.sf.jstuff.core.compression.AbstractCompression;
import net.sf.jstuff.core.io.IOUtils;
import net.sf.jstuff.core.io.stream.DelegatingOutputStream;
import net.sf.jstuff.core.validation.Args;

/**
 * @author <a href="https://sebthom.de/">Sebastian Thomschke</a>
 */
public class SnappyCompression extends AbstractCompression {

   private static final int DEFAULT_BLOCK_SIZE = 64 * 1024;

   public static final SnappyCompression INSTANCE = new SnappyCompression();

   protected SnappyCompression() {
      // prevent instantiation
   }

   @Override
   @SuppressWarnings("resource")
   public void compress(final byte[] uncompressed, OutputStream output) throws IOException {
      Args.notNull("uncompressed", uncompressed);
      Args.notNull("output", output);

      // prevent closing of underlying outputstream but allow closing of overlaying compressing outputstream
      output = new DelegatingOutputStream(output, true);

      try (OutputStream compOS = createCompressingOutputStream(output)) {
         compOS.write(uncompressed);
         compOS.flush();
      }
   }

   @Override
   @SuppressWarnings("resource")
   public void compress(final InputStream uncompressed, OutputStream output) throws IOException {
      Args.notNull("uncompressed", uncompressed);
      Args.notNull("output", output);

      // prevent closing of underlying outputstream but allow closing of overlaying compressing outputstream
      output = new DelegatingOutputStream(output, true);

      try (OutputStream compOS = createCompressingOutputStream(output)) {
         IOUtils.copyLarge(uncompressed, compOS);
         compOS.flush();
      }
   }

   @Override
   public InputStream createDecompressingInputStream(final InputStream compressed) throws IOException {
      return new SnappyInputStream(compressed);
   }

   @Override
   public OutputStream createCompressingOutputStream(final OutputStream output) throws IOException {
      return new SnappyOutputStream(output, DEFAULT_BLOCK_SIZE);
   }

   @Override
   public String toString() {
      return Strings.toString(this, ArrayUtils.EMPTY_OBJECT_ARRAY);
   }
}
