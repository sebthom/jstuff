/*
 * SPDX-FileCopyrightText: © Sebastian Thomschke and contributors
 * SPDX-License-Identifier: EPL-2.0
 *
 * @author Sebastian Thomschke
 */
@NonNullByDefault
package net.sf.jstuff.core.reflection.exception;

import org.eclipse.jdt.annotation.NonNullByDefault;
