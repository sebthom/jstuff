/*
 * SPDX-FileCopyrightText: © Sebastian Thomschke and contributors
 * SPDX-License-Identifier: EPL-2.0
 */
package net.sf.jstuff.core;

import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.concurrent.BasicThreadFactory;

import net.sf.jstuff.core.concurrent.ThreadSafe;
import net.sf.jstuff.core.event.EventListenable;
import net.sf.jstuff.core.event.EventListener;
import net.sf.jstuff.core.event.SyncEventDispatcher;
import net.sf.jstuff.core.logging.Logger;
import net.sf.jstuff.core.validation.Args;

/**
 * Tracks garbage collection of registered objects and executes callbacks in the event of garbage collection.
 *
 * @author <a href="https://sebthom.de/">Sebastian Thomschke</a>
 */
@ThreadSafe
public class GCTracker<EVENT> implements EventListenable<EVENT> {
   /**
    * https://www.mindprod.com/jgloss/phantom.html
    * https://medium.com/yohan-liyanage/know-the-jvm-series-3-when-weaker-is-better-understanding-soft-weak-and-phantom-references-cbed297b9e2e
    */
   private final class GCReference extends PhantomReference<Object> {
      private final EVENT eventToFireOnGC;
      private final GCTracker<EVENT> tracker;

      protected GCReference(final Object trackedObject, final EVENT eventToFireOnGC, final GCTracker<EVENT> tracker) {
         super(trackedObject, garbageCollectedRefs);
         this.eventToFireOnGC = eventToFireOnGC;
         this.tracker = tracker;
      }
   }

   private static final class LazyInitialized {
      private static final ScheduledExecutorService DEFAULT_NOTIFICATION_THREAD = Executors.newSingleThreadScheduledExecutor(
         BasicThreadFactory.builder().daemon(true).priority(Thread.NORM_PRIORITY).namingPattern("GCTracker-thread").build());
   }

   private static final Logger LOG = Logger.create();

   private final SyncEventDispatcher<EVENT> events = new SyncEventDispatcher<>();

   /**
    * synchronized list that holds the GCReference objects to prevent them from being garbage collected before their reference is garbage
    * collected
    */
   private final Queue<GCReference> monitoredReferences = new ConcurrentLinkedQueue<>();
   private final ReferenceQueue<Object> garbageCollectedRefs = new ReferenceQueue<>();

   private volatile ScheduledExecutorService executor;

   private final int intervalMS;

   public GCTracker(final int intervalMS) {
      this.intervalMS = intervalMS;
      executor = LazyInitialized.DEFAULT_NOTIFICATION_THREAD;
      init();
   }

   public GCTracker(final int intervalMS, final ScheduledExecutorService executor) {
      this.intervalMS = intervalMS;
      Args.notNull("executor", executor);
      this.executor = executor;
      init();
   }

   @SuppressWarnings("unchecked")
   private void init() {
      executor.scheduleWithFixedDelay(() -> {
         GCReference ref;
         while ((ref = (GCReference) garbageCollectedRefs.poll()) != null) {
            ref.tracker.monitoredReferences.remove(ref);
            try {
               ref.tracker.onGCEvent(ref.eventToFireOnGC);
            } catch (final Exception ex) {
               LOG.error(ex, "Failed to execute callback.");
            }
         }
      }, intervalMS, intervalMS, TimeUnit.MILLISECONDS);
   }

   protected void onGCEvent(final EVENT event) {
      events.fire(event);
   }

   @Override
   public boolean subscribe(final EventListener<EVENT> listener) {
      return events.subscribe(listener);
   }

   /**
    * <b>Important:</b> <code>eventToFireOnGC</code> must not have a direct or indirect hard reference to <code>target</code>, otherwise you
    * are producing a memory leak by preventing garbage collection of <code>target</code>.
    *
    * @param subject the object whose garbage collection should be tracked
    * @param eventToFireOnGC an event that is fired on garbage collection of <code>target</code>
    */
   public void track(final Object subject, final EVENT eventToFireOnGC) {
      Args.notNull("subject", subject);

      if (subject == eventToFireOnGC)
         throw new IllegalArgumentException(
            "eventToFireOnGC callback cannot be the same as the target, this avoids garbage collection of target.");

      monitoredReferences.add(new GCReference(subject, eventToFireOnGC, this));
   }

   @Override
   public boolean unsubscribe(final EventListener<EVENT> listener) {
      return events.unsubscribe(listener);
   }
}
