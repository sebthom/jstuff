/*********************************************************************
 * Copyright 2010-2020 by Sebastian Thomschke and others.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *********************************************************************/
package net.sf.jstuff.core.logging;

import java.util.Set;

import net.sf.jstuff.core.collection.WeakIdentityHashSet;
import net.sf.jstuff.core.validation.Args;

/**
 * @author <a href="http://sebthom.de/">Sebastian Thomschke</a>
 */
public final class LoggerConfig {
   private static final Logger LOG;

   /**
    * weak set holding all instantiated loggers. required to switch the backing logger implementation during runtime if required.
    */
   private static final Set<DelegatingLogger> LOGGERS = new WeakIdentityHashSet<>(64);

   private static final boolean isSLF4JAvailable; // CHECKSTYLE:IGNORE ConstantName
   private static boolean isPreferSLF4J;
   static boolean isSanitizeStrackTracesEnabled = true;
   private static boolean isUseSFL4J;

   /**
    * If set to true, method name and line number are added to the log message.
    * This is esp. helpful in environments where you have no control over the used logger pattern by the underlying logger infrastructure (e.g. in an JEE
    * container).
    */
   static boolean isDebugMessagePrefixEnabled;
   static boolean isCompactExceptionLoggingEnabled;

   static {
      LinkageError slf4jLinkageError = null;
      try {
         @SuppressWarnings("unused")
         final SLF4JLogger test = new SLF4JLogger("");
      } catch (final LinkageError err) {
         slf4jLinkageError = err;
      }
      isSLF4JAvailable = slf4jLinkageError == null;

      LOG = create(LoggerConfig.class.getName());
      if (slf4jLinkageError != null) {
         LOG.trace(slf4jLinkageError);
      }

      setPreferSLF4J("true".equals(System.getProperty(Logger.class.getName() + ".preferSLF4J", "true")));
   }

   static Logger create(final String name) {
      Args.notNull("name", name);

      final DelegatingLogger logger = new DelegatingLogger(isUseSFL4J ? new SLF4JLogger(name) : new JULLogger(name));
      synchronized (LOGGERS) {
         LOGGERS.add(logger);
      }
      return logger;
   }

   public static boolean isCompactExceptionLoggingEnabled() {
      return isCompactExceptionLoggingEnabled;
   }

   public static boolean isDebugMessagePrefixEnabled() {
      return isDebugMessagePrefixEnabled;
   }

   public static boolean isPreferSLF4J() {
      return isPreferSLF4J;
   }

   public static boolean isSanitizeStrackTracesEnabled() {
      return isSanitizeStrackTracesEnabled;
   }

   public static void setCompactExceptionLogging(final boolean enabled) {
      isCompactExceptionLoggingEnabled = enabled;
   }

   public static void setDebugMessagePrefixEnabled(final boolean enabled) {
      LoggerConfig.isDebugMessagePrefixEnabled = enabled;
   }

   public static synchronized void setPreferSLF4J(final boolean value) {
      isPreferSLF4J = value;
      final boolean old = isUseSFL4J;
      isUseSFL4J = isSLF4JAvailable && isPreferSLF4J;
      if (old == isUseSFL4J)
         return;

      synchronized (LOGGERS) {
         // hot replacing the underlying logger infrastructure
         for (final DelegatingLogger logger : LOGGERS) {
            final String name = logger.getName();
            logger.setWrapped(isUseSFL4J ? new SLF4JLogger(name) : new JULLogger(name));
         }

         if (isUseSFL4J) {
            LOG.debug("Using SLF4J as logging infrastructure.");
         } else {
            LOG.debug("Using java.util.logging as logging infrastructure.");
         }
      }
   }

   public static void setSanitizeStackTraces(final boolean enabled) {
      isSanitizeStrackTracesEnabled = enabled;
   }

   private LoggerConfig() {
   }
}
