/*
 * Copyright 2010-2021 by Sebastian Thomschke and contributors.
 * SPDX-License-Identifier: EPL-2.0
 */
package net.sf.jstuff.core.compression;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import net.sf.jstuff.core.Strings;
import net.sf.jstuff.core.io.IOUtils;
import net.sf.jstuff.core.io.stream.DelegatingOutputStream;
import net.sf.jstuff.core.validation.Args;

/**
 * Compress/decompress using "gzip" compression format.
 *
 * GZip is deflate plus CRC32 checksum
 *
 * @author <a href="https://sebthom.de/">Sebastian Thomschke</a>
 */
public class GZipCompression extends AbstractCompression {

   /**
    * Shared instance with compression level 4.
    *
    * See https://www.rootusers.com/gzip-vs-bzip2-vs-xz-performance-comparison/#attachment_1478
    */
   public static final GZipCompression INSTANCE = new GZipCompression(4);

   private final int compressionLevel;

   public GZipCompression(final int compressionLevel) {
      this.compressionLevel = compressionLevel;
   }

   @Override
   @SuppressWarnings("resource")
   public void compress(final byte[] uncompressed, OutputStream output) throws IOException {
      Args.notNull("uncompressed", uncompressed);
      Args.notNull("output", output);

      // prevent closing of underlying outputstream but allow closing of overlaying compressing outputstream
      output = new DelegatingOutputStream(output, true);

      try (GZIPOutputStream compOS = (GZIPOutputStream) createCompressingOutputStream(output)) {
         compOS.write(uncompressed);
         compOS.finish();
      }
   }

   @Override
   @SuppressWarnings("resource")
   public void compress(final InputStream uncompressed, OutputStream output) throws IOException {
      Args.notNull("uncompressed", uncompressed);
      Args.notNull("output", output);

      // prevent closing of underlying outputstream but allow closing of overlaying compressing outputstream
      output = new DelegatingOutputStream(output, true);

      try (GZIPOutputStream compOS = (GZIPOutputStream) createCompressingOutputStream(output)) {
         IOUtils.copyLarge(uncompressed, compOS);
         compOS.finish();
      }
   }

   @Override
   public InputStream createCompressingInputStream(final InputStream uncompressed) throws IOException {
      return new GZIPCompressingInputStream(uncompressed, compressionLevel);
   }

   @Override
   public OutputStream createCompressingOutputStream(final OutputStream output) throws IOException {
      return new GZIPOutputStream(output) {
         {
            def.setLevel(compressionLevel);
         }
      };
   }

   @Override
   public InputStream createDecompressingInputStream(final InputStream compressed) throws IOException {
      return new GZIPInputStream(compressed);
   }

   public int getCompressionLevel() {
      return compressionLevel;
   }

   @Override
   public String toString() {
      return Strings.toString(this, "compressionLevel", compressionLevel);
   }
}
